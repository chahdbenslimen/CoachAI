package com.productivity.service;

import com.productivity.dao.UserDAO;
import com.productivity.model.User;
import com.productivity.util.SessionManager;

public class UserService {

    private final UserDAO userDAO = new UserDAO();

    public boolean register(String username, String email, String password,
                            String workRhythm, int weeklyGoalHours) {
        if (username.isBlank() || email.isBlank() || password.length() < 6) return false;

        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setWorkRhythm(workRhythm);
        user.setWeeklyGoalHours(weeklyGoalHours);

        return userDAO.register(user, password);
    }

    public boolean login(String username, String password) {
        User user = userDAO.login(username, password);
        if (user != null) {
            SessionManager.getInstance().setCurrentUser(user);
            return true;
        }
        return false;
    }

    public boolean updateProfile(String email, String workRhythm, int weeklyGoalHours) {
        User user = SessionManager.getInstance().getCurrentUser();
        user.setEmail(email);
        user.setWorkRhythm(workRhythm);
        user.setWeeklyGoalHours(weeklyGoalHours);
        return userDAO.updateProfile(user);
    }

    public void logout() {
        SessionManager.getInstance().logout();
    }
}
