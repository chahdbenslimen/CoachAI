package com.productivity.model;

import java.time.LocalDateTime;

public class User {

    private int id;
    private String username;
    private String email;
    private String passwordHash;
    private String workRhythm;
    private int weeklyGoalHours;
    private LocalDateTime createdAt;

    public User() {}

    public User(int id, String username, String email, String workRhythm, int weeklyGoalHours) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.workRhythm = workRhythm;
        this.weeklyGoalHours = weeklyGoalHours;
    }

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }

    public String getWorkRhythm() { return workRhythm; }
    public void setWorkRhythm(String workRhythm) { this.workRhythm = workRhythm; }

    public int getWeeklyGoalHours() { return weeklyGoalHours; }
    public void setWeeklyGoalHours(int weeklyGoalHours) { this.weeklyGoalHours = weeklyGoalHours; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "'}";
    }
}
