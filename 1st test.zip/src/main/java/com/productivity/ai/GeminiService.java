package com.productivity.ai;

import io.github.cdimascio.dotenv.Dotenv;
import okhttp3.*;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.concurrent.TimeUnit;

public class GeminiService {

    private static final String API_KEY = loadApiKey();
    private static final String BASE_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-lite:generateContent";

    private final OkHttpClient client;

    public GeminiService() {
        client = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build();
    }

    private static String loadApiKey() {
        try {
            Dotenv dotenv = Dotenv.configure()
                    .directory(System.getProperty("user.dir"))
                    .ignoreIfMissing()
                    .load();
            String key = dotenv.get("GEMINI_API_KEY");
            if (key == null || key.isBlank()) {
                System.err.println("❌ GEMINI_API_KEY est vide ou introuvable dans .env");
                return "";
            }
            System.out.println("✅ Clé API chargée avec succès");
            return key;
        } catch (Exception e) {
            System.err.println("❌ Erreur chargement .env : " + e.getMessage());
            return "";
        }
    }

    public String reformulateObjective(String vagueText) {
        String prompt = """
                Tu es un coach de productivité expert. L'utilisateur a écrit un objectif flou.
                Reformule-le en un objectif SMART clair, actionnable et motivant.
                Réponds uniquement avec la reformulation, sans introduction.
                
                Objectif flou: "%s"
                """.formatted(vagueText);
        return callGemini(prompt);
    }

    public String suggestPriority(String title, String description, String deadline, String category) {
        String prompt = """
                Tu es un expert en gestion du temps. Analyse cette tâche et suggère une priorité.
                Réponds avec: [PRIORITÉ: low/medium/high/urgent] suivi d'une explication courte (2 phrases max).
                
                Tâche: %s
                Description: %s
                Échéance: %s
                Catégorie: %s
                """.formatted(title, description, deadline, category);
        return callGemini(prompt);
    }

    public String breakdownTask(String taskTitle, String taskDescription, int estimatedDays) {
        String prompt = """
                Tu es un coach de productivité. Décompose cette tâche en sous-tâches concrètes et réalisables.
                Génère entre 4 et 8 sous-tâches numérotées. Chaque sous-tâche sur une nouvelle ligne.
                Format: 1. [sous-tâche]
                
                Tâche principale: %s
                Description: %s
                Durée estimée: %d jours
                """.formatted(taskTitle, taskDescription, estimatedDays);
        return callGemini(prompt);
    }

    public String generatePlan(String taskTitle, String deadline, String userRhythm) {
        String prompt = """
                Tu es un coach de productivité. Crée un plan de travail structuré jour par jour.
                L'utilisateur travaille mieux le: %s.
                Format: Jour X - [activité concrète]
                Sois précis, motivant et réaliste.
                
                Tâche: %s
                Date limite: %s
                """.formatted(userRhythm, taskTitle, deadline);
        return callGemini(prompt);
    }

    public String getPersonalizedAdvice(int completedTasks, int pendingTasks, double totalHours, String rhythm) {
        String prompt = """
                Tu es un coach de productivité bienveillant. Donne un conseil personnalisé court (3-4 phrases max).
                Sois encourageant et pratique. Adapte le conseil au rythme de travail de l'utilisateur.
                
                Statistiques:
                - Tâches complétées: %d
                - Tâches en attente: %d
                - Heures de travail total: %.1f h
                - Rythme préféré: %s
                """.formatted(completedTasks, pendingTasks, totalHours, rhythm);
        return callGemini(prompt);
    }

    private String callGemini(String prompt) {
        if (API_KEY == null || API_KEY.isBlank()) {
            return "❌ Clé API manquante. Vérifie ton fichier .env";
        }

        try {
            JSONObject requestBody = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject content = new JSONObject();
            JSONArray parts = new JSONArray();
            JSONObject part = new JSONObject();

            part.put("text", prompt);
            parts.put(part);
            content.put("parts", parts);
            contents.put(content);
            requestBody.put("contents", contents);

            JSONObject genConfig = new JSONObject();
            genConfig.put("temperature", 0.7);
            genConfig.put("maxOutputTokens", 1024);
            requestBody.put("generationConfig", genConfig);

            RequestBody body = RequestBody.create(
                    requestBody.toString(),
                    MediaType.parse("application/json")
            );

            Request request = new Request.Builder()
                    .url(BASE_URL + "?key=" + API_KEY)
                    .post(body)
                    .build();

            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful()) {
                    String errorBody = response.body() != null ? response.body().string() : "no body";
                    System.err.println("❌ Gemini error " + response.code() + ": " + errorBody);
                    return "❌ Erreur API (" + response.code() + "): " + errorBody;                }

                String responseStr = response.body().string();
                JSONObject json = new JSONObject(responseStr);
                return json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text");
            }

        } catch (Exception e) {
            System.err.println("❌ Exception Gemini: " + e.getMessage());
            return "❌ Erreur de connexion: " + e.getMessage();
        }
    }
}