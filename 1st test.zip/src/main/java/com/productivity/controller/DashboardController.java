import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.Parent;
import javafx.stage.Stage;
import java.io.IOException;

public class DashboardController {

    // ------------------- FXML Fields -------------------
    @FXML private StackPane contentArea;
    @FXML private Label welcomeLabel;
    @FXML private Label completedCount;
    @FXML private Label inProgressCount;
    @FXML private Label todoCount;
    @FXML private Label hoursCount;
    @FXML private Label aiAdviceLabel;
    @FXML private ListView recentTasksList;
    @FXML private Label usernameLabel;

    // ------------------- Initialize -------------------
    @FXML
    private void initialize() {
        // Load dashboard home by default
        showDashboard();
    }

    // ------------------- Button Actions -------------------

    // Tableau de bord
    @FXML
    private void showDashboard() {
        try {
            VBox dashboard = FXMLLoader.load(getClass().getResource("/fxml/dashboardhome.fxml"));
            contentArea.getChildren().setAll(dashboard);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading dashboardhome.fxml");
        }
    }

    // Mes tâches
    @FXML
    private void showTasks() {
        try {
            VBox tasks = FXMLLoader.load(getClass().getResource("/fxml/Tasks.fxml"));
            contentArea.getChildren().setAll(tasks);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading Tasks.fxml");
        }
    }

    // Assistant IA
    @FXML
    private void showAI() {
        try {
            VBox aiContent = FXMLLoader.load(getClass().getResource("/fxml/AIAssistant.fxml"));
            contentArea.getChildren().setAll(aiContent);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading AIAssistant.fxm");
        }
    }

    // Statistiques
    @FXML
    private void showStats() {
        try {
            VBox stats = FXMLLoader.load(getClass().getResource("/fxml/Stats.fxml"));
            contentArea.getChildren().setAll(stats);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading Stats.fxml");
        }
    }

    // Profil
    @FXML
    private void showProfile() {
        try {
            VBox profile = FXMLLoader.load(getClass().getResource("/fxml/Profile.fxml"));
            contentArea.getChildren().setAll(profile);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading Profile.fxml");
        }
    }

    // Déconnexion
    @FXML
    private void handleLogout() {
        try {
            Parent login = FXMLLoader.load(getClass().getResource("/fxml/Login.fxml"));
            Stage stage = (Stage) contentArea.getScene().getWindow();
            stage.getScene().setRoot(login);
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error loading Login.fxml");
        }
    }

    // Refresh AI Advice (if you use it)
    @FXML
    private void refreshAdvice() {
        // Example: random advice
        String[] adviceList = {
                "Planifiez vos tâches avant de commencer",
                "Prenez des pauses régulières",
                "Concentrez-vous sur une tâche à la fois",
                "Priorisez l'important, pas l'urgent"
        };
        int index = (int) (Math.random() * adviceList.length);
        aiAdviceLabel.setText(adviceList[index]);
    }
}