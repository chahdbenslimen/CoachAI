package com.productivity.controller;

import com.productivity.model.Task;
import com.productivity.service.TaskService;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class AIAssistantController implements Initializable {

    @FXML private TextField reformulateInput;
    @FXML private Label     reformulateResult;

    @FXML private ComboBox<Task> taskCombo;
    @FXML private Label          priorityResult;

    @FXML private ComboBox<Task> breakdownCombo;
    @FXML private Spinner<Integer> daysSpinner;
    @FXML private TextArea       breakdownResult;

    @FXML private ComboBox<Task> planCombo;
    @FXML private TextArea       planResult;

    private final TaskService taskService = new TaskService();
    private List<Task> tasks;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        tasks = taskService.getUserTasks();
        daysSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 60, 7));

        taskCombo.setItems(FXCollections.observableArrayList(tasks));
        breakdownCombo.setItems(FXCollections.observableArrayList(tasks));
        planCombo.setItems(FXCollections.observableArrayList(tasks));
    }

    @FXML
    private void handleReformulate() {
        String text = reformulateInput.getText().trim();
        if (text.isEmpty()) { reformulateResult.setText("Entrez un texte à reformuler."); return; }

        reformulateResult.setText("⏳ Reformulation en cours...");
        new Thread(() -> {
            String result = taskService.reformulateObjective(text);
            Platform.runLater(() -> reformulateResult.setText(result));
        }).start();
    }

    @FXML
    private void handleSuggestPriority() {
        Task task = taskCombo.getValue();
        if (task == null) { priorityResult.setText("Sélectionnez une tâche."); return; }

        priorityResult.setText("⏳ Analyse en cours...");
        new Thread(() -> {
            String result = taskService.suggestPriority(task);
            Platform.runLater(() -> priorityResult.setText(result));
        }).start();
    }

    @FXML
    private void handleBreakdown() {
        Task task = breakdownCombo.getValue();
        if (task == null) { breakdownResult.setText("Sélectionnez une tâche."); return; }

        int days = daysSpinner.getValue();
        breakdownResult.setText("⏳ Génération des sous-tâches...");
        new Thread(() -> {
            String result = taskService.breakdownTask(task, days);
            Platform.runLater(() -> breakdownResult.setText(result));
        }).start();
    }

    @FXML
    private void handlePlan() {
        Task task = planCombo.getValue();
        if (task == null) { planResult.setText("Sélectionnez une tâche."); return; }

        planResult.setText("⏳ Création du plan...");
        new Thread(() -> {
            String result = taskService.generatePlan(task);
            Platform.runLater(() -> planResult.setText(result));
        }).start();
    }
}
