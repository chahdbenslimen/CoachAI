package com.productivity.controller;

import com.productivity.service.UserService;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {

    @FXML private TextField usernameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private ComboBox<String> rhythmCombo;
    @FXML private Spinner<Integer> hoursSpinner;
    @FXML private Label errorLabel;

    private final UserService userService = new UserService();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        rhythmCombo.getItems().addAll("morning", "afternoon", "evening", "flexible");
        rhythmCombo.setValue("flexible");
        hoursSpinner.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 80, 20));
    }

    @FXML
    private void handleRegister() {
        String username = usernameField.getText().trim();
        String email    = emailField.getText().trim();
        String password = passwordField.getText();
        String rhythm   = rhythmCombo.getValue();
        int hours       = hoursSpinner.getValue();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            showError("Veuillez remplir tous les champs.");
            return;
        }
        if (password.length() < 6) {
            showError("Le mot de passe doit contenir au moins 6 caractères.");
            return;
        }

        if (userService.register(username, email, password, rhythm, hours)) {
            loadScene("/fxml/Login.fxml", 480, 560);
        } else {
            showError("Nom d'utilisateur ou email déjà utilisé.");
        }
    }

    @FXML
    private void goToLogin() {
        loadScene("/fxml/Login.fxml", 480, 560);
    }

    private void showError(String msg) {
        errorLabel.setText(msg);
        errorLabel.setVisible(true);
    }

    private void loadScene(String fxmlPath, int width, int height) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource(fxmlPath));
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.setScene(new Scene(root, width, height));
            stage.centerOnScreen();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
