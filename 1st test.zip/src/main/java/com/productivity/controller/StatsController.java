package com.productivity.controller;

import com.productivity.model.Task;
import com.productivity.service.TaskService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class StatsController implements Initializable {

    @FXML private Label statCompleted, statInProgress, statTodo, statHours;
    @FXML private ProgressBar completionBar;
    @FXML private Label completionLabel;
    @FXML private Label catStudies, catWork, catPersonal;

    @FXML private TableView<Task> historyTable;
    @FXML private TableColumn<Task, String> hColTitle, hColCategory, hColStatus,
                                             hColEstHours, hColActHours, hColDeadline;

    private final TaskService taskService = new TaskService();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        int completed   = taskService.countCompleted();
        int inProgress  = taskService.countInProgress();
        int todo        = taskService.countTodo();
        double hours    = taskService.totalHours();
        int total       = completed + inProgress + todo;

        statCompleted.setText(String.valueOf(completed));
        statInProgress.setText(String.valueOf(inProgress));
        statTodo.setText(String.valueOf(todo));
        statHours.setText(String.format("%.1f", hours));

        double rate = total == 0 ? 0 : (double) completed / total;
        completionBar.setProgress(rate);
        completionLabel.setText(String.format("%.0f%% des tâches complétées (%d / %d)", rate * 100, completed, total));

        // Category counts
        List<Task> tasks = taskService.getUserTasks();
        long studies = tasks.stream().filter(t -> t.getCategory() == Task.Category.studies).count();
        long work    = tasks.stream().filter(t -> t.getCategory() == Task.Category.work).count();
        long personal= tasks.stream().filter(t -> t.getCategory() == Task.Category.personal).count();
        catStudies.setText(String.valueOf(studies));
        catWork.setText(String.valueOf(work));
        catPersonal.setText(String.valueOf(personal));

        // History table
        hColTitle.setCellValueFactory(c    -> new SimpleStringProperty(c.getValue().getTitle()));
        hColCategory.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCategory().name()));
        hColStatus.setCellValueFactory(c   -> new SimpleStringProperty(c.getValue().getStatus().name().replace("_"," ")));
        hColEstHours.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getEstimatedHours())));
        hColActHours.setCellValueFactory(c -> new SimpleStringProperty(String.valueOf(c.getValue().getActualHours())));
        hColDeadline.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getDeadline() != null ? c.getValue().getDeadline().toString() : "-"));

        historyTable.setItems(FXCollections.observableArrayList(tasks));
    }
}
