package com.productivity.controller;

import com.productivity.model.User;
import com.productivity.service.UserService;
import com.productivity.util.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;

import java.net.URL;
import java.util.ResourceBundle;

public class ProfileController implements Initializable {

    @FXML private Label usernameDisplay;
    @FXML private Label memberSince;
    @FXML private TextField emailField;
    @FXML private ComboBox<String> rhythmCombo;
    @FXML private Spinner<Integer> hoursSpinner;
    @FXML private Label messageLabel;

    private final UserService userService = new UserService();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        User user = SessionManager.getInstance().getCurrentUser();

        usernameDisplay.setText("👤 " + user.getUsername());
        if (user.getCreatedAt() != null)
            memberSince.setText("Membre depuis : " + user.getCreatedAt().toLocalDate());

        emailField.setText(user.getEmail());

        rhythmCombo.getItems().addAll("morning", "afternoon", "evening", "flexible");
        rhythmCombo.setValue(user.getWorkRhythm() != null ? user.getWorkRhythm() : "flexible");

        hoursSpinner.setValueFactory(
                new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 80, user.getWeeklyGoalHours()));
    }

    @FXML
    private void handleSave() {
        String email  = emailField.getText().trim();
        String rhythm = rhythmCombo.getValue();
        int hours     = hoursSpinner.getValue();

        if (email.isEmpty()) {
            showMessage("L'email ne peut pas être vide.", false);
            return;
        }

        if (userService.updateProfile(email, rhythm, hours)) {
            showMessage("✅ Profil mis à jour avec succès !", true);
        } else {
            showMessage("❌ Erreur lors de la mise à jour.", false);
        }
    }

    private void showMessage(String msg, boolean success) {
        messageLabel.setText(msg);
        messageLabel.setStyle(success
                ? "-fx-text-fill:#66BB6A;-fx-font-size:12px;"
                : "-fx-text-fill:#EF5350;-fx-font-size:12px;");
        messageLabel.setVisible(true);
    }
}
