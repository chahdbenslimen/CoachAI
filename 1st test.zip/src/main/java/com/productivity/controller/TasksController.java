package com.productivity.controller;

import com.productivity.model.Subtask;
import com.productivity.model.Task;
import com.productivity.service.TaskService;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.net.URL;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class TasksController implements Initializable {

    @FXML private TableView<Task> taskTable;
    @FXML private TableColumn<Task, String>  colPriority;
    @FXML private TableColumn<Task, String>  colTitle;
    @FXML private TableColumn<Task, String>  colCategory;
    @FXML private TableColumn<Task, String>  colStatus;
    @FXML private TableColumn<Task, String>  colDeadline;
    @FXML private TableColumn<Task, String>  colProgress;
    @FXML private TableColumn<Task, Void>    colActions;
    @FXML private ComboBox<String> statusFilter;
    @FXML private ComboBox<String> categoryFilter;
    @FXML private ComboBox<String> priorityFilter;

    private final TaskService taskService = new TaskService();
    private ObservableList<Task> allTasks = FXCollections.observableArrayList();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        setupFilters();
        setupTable();
        loadTasks();
    }

    private void setupFilters() {
        statusFilter.getItems().addAll("Tous", "todo", "in_progress", "completed", "cancelled");
        categoryFilter.getItems().addAll("Tous", "studies", "work", "personal");
        priorityFilter.getItems().addAll("Tous", "low", "medium", "high", "urgent");
        statusFilter.setValue("Tous");
        categoryFilter.setValue("Tous");
        priorityFilter.setValue("Tous");
    }

    private void setupTable() {
        colPriority.setCellValueFactory(c -> {
            String icon = switch (c.getValue().getPriority()) {
                case urgent -> "🔴";
                case high   -> "🟠";
                case medium -> "🟡";
                case low    -> "🟢";
            };
            return new SimpleStringProperty(icon);
        });

        colTitle.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getTitle()));
        colCategory.setCellValueFactory(c -> new SimpleStringProperty(c.getValue().getCategory().name()));
        colStatus.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getStatus().name().replace("_", " ")));
        colDeadline.setCellValueFactory(c -> new SimpleStringProperty(
                c.getValue().getDeadline() != null ? c.getValue().getDeadline().toString() : "-"));

        colProgress.setCellValueFactory(c -> {
            Task t = c.getValue();
            long total = t.getSubtasks().size();
            long done  = t.getSubtasks().stream().filter(Subtask::isCompleted).count();
            return new SimpleStringProperty(total == 0 ? "-" : done + "/" + total);
        });

        // Actions column
        colActions.setCellFactory(col -> new TableCell<>() {
            private final Button editBtn   = new Button("✏️");
            private final Button deleteBtn = new Button("🗑️");
            private final Button detailBtn = new Button("👁️");
            private final HBox box = new HBox(4, detailBtn, editBtn, deleteBtn);

            {
                editBtn.setStyle("-fx-background-color:#6C63FF;-fx-text-fill:white;-fx-background-radius:6;-fx-cursor:hand;");
                deleteBtn.setStyle("-fx-background-color:#E53935;-fx-text-fill:white;-fx-background-radius:6;-fx-cursor:hand;");
                detailBtn.setStyle("-fx-background-color:#2A2D3E;-fx-text-fill:white;-fx-background-radius:6;-fx-cursor:hand;");

                editBtn.setOnAction(e -> {
                    Task t = getTableView().getItems().get(getIndex());
                    openEditTask(t);
                });
                deleteBtn.setOnAction(e -> {
                    Task t = getTableView().getItems().get(getIndex());
                    handleDelete(t);
                });
                detailBtn.setOnAction(e -> {
                    Task t = getTableView().getItems().get(getIndex());
                    openDetailDialog(t);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : box);
            }
        });
    }

    private void loadTasks() {
        allTasks.setAll(taskService.getUserTasks());
        taskTable.setItems(allTasks);
    }

    @FXML
    private void applyFilter() {
        String status   = statusFilter.getValue();
        String category = categoryFilter.getValue();
        String priority = priorityFilter.getValue();

        ObservableList<Task> filtered = allTasks.filtered(t ->
                (status.equals("Tous")   || t.getStatus().name().equals(status))   &&
                (category.equals("Tous") || t.getCategory().name().equals(category)) &&
                (priority.equals("Tous") || t.getPriority().name().equals(priority))
        );
        taskTable.setItems(filtered);
    }

    @FXML
    private void resetFilter() {
        statusFilter.setOnAction(null);
        categoryFilter.setOnAction(null);
        priorityFilter.setOnAction(null);

        statusFilter.setValue("Tous");
        categoryFilter.setValue("Tous");
        priorityFilter.setValue("Tous");

        statusFilter.setOnAction(e -> applyFilter());
        categoryFilter.setOnAction(e -> applyFilter());
        priorityFilter.setOnAction(e -> applyFilter());

        loadTasks();
    }

    @FXML
    private void openAddTask() {
        showTaskDialog(null);
    }

    private void openEditTask(Task task) {
        showTaskDialog(task);
    }

    private void handleDelete(Task task) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                "Supprimer la tâche \"" + task.getTitle() + "\" ?",
                ButtonType.YES, ButtonType.NO);
        styleAlert(confirm);
        confirm.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                taskService.deleteTask(task.getId());
                loadTasks();
            }
        });
    }

    // ── Task Dialog (Add / Edit) ──────────────────────────────────────────────

    private void showTaskDialog(Task existing) {
        Dialog<Task> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Nouvelle Tâche" : "Modifier la Tâche");
        dialog.getDialogPane().getStylesheets().add(getClass().getResource("/css/style.css").toExternalForm());
        dialog.getDialogPane().setStyle("-fx-background-color:#1E2130;");

        // Form fields
        TextField titleField   = styledTextField("Titre de la tâche");
        TextArea  descArea     = new TextArea();
        descArea.setPromptText("Description (optionnel)");
        descArea.setPrefRowCount(3);
        descArea.setStyle("-fx-background-color:#2A2D3E;-fx-text-fill:#E0E0E0;-fx-background-radius:8;");

        ComboBox<String> catBox  = new ComboBox<>();
        catBox.getItems().addAll("studies", "work", "personal");
        catBox.setValue("personal");
        catBox.setStyle("-fx-background-color:#2A2D3E;-fx-text-fill:#E0E0E0;");

        ComboBox<String> priBox  = new ComboBox<>();
        priBox.getItems().addAll("low", "medium", "high", "urgent");
        priBox.setValue("medium");
        priBox.setStyle("-fx-background-color:#2A2D3E;-fx-text-fill:#E0E0E0;");

        ComboBox<String> statusBox = new ComboBox<>();
        statusBox.getItems().addAll("todo", "in_progress", "completed", "cancelled");
        statusBox.setValue("todo");
        statusBox.setStyle("-fx-background-color:#2A2D3E;-fx-text-fill:#E0E0E0;");

        DatePicker deadlinePicker = new DatePicker();
        deadlinePicker.setStyle("-fx-background-color:#2A2D3E;-fx-text-fill:#E0E0E0;");

        Spinner<Double> estHours = new Spinner<>(0.0, 200.0, 1.0, 0.5);
        estHours.setEditable(true);
        estHours.setStyle("-fx-background-color:#2A2D3E;");

        // Pre-fill if editing
        if (existing != null) {
            titleField.setText(existing.getTitle());
            descArea.setText(existing.getDescription());
            catBox.setValue(existing.getCategory().name());
            priBox.setValue(existing.getPriority().name());
            statusBox.setValue(existing.getStatus().name());
            deadlinePicker.setValue(existing.getDeadline());
            estHours.getValueFactory().setValue(existing.getEstimatedHours());
        }

        VBox form = new VBox(8,
                label("Titre *"), titleField,
                label("Description"), descArea,
                label("Catégorie"), catBox,
                label("Priorité"), priBox,
                label("Statut"), statusBox,
                label("Échéance"), deadlinePicker,
                label("Heures estimées"), estHours
        );
        form.setPadding(new Insets(10));
        form.setStyle("-fx-background-color:#1E2130;");

        dialog.getDialogPane().setContent(form);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                Task t = existing != null ? existing : new Task();
                t.setTitle(titleField.getText().trim());
                t.setDescription(descArea.getText().trim());
                t.setCategory(Task.Category.valueOf(catBox.getValue()));
                t.setPriority(Task.Priority.valueOf(priBox.getValue()));
                t.setStatus(Task.Status.valueOf(statusBox.getValue()));
                t.setDeadline(deadlinePicker.getValue());
                t.setEstimatedHours(estHours.getValue());
                return t;
            }
            return null;
        });

        Optional<Task> result = dialog.showAndWait();
        result.ifPresent(t -> {
            if (t.getTitle().isEmpty()) return;
            if (existing == null) taskService.createTask(t);
            else taskService.updateTask(t);
            loadTasks();
        });
    }

    // ── Detail / Subtasks Dialog ──────────────────────────────────────────────

    private void openDetailDialog(Task task) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Détail de la tâche");
        alert.setHeaderText(task.getTitle());
        alert.getDialogPane().getStylesheets().add(getClass().getResource("/css/style.css").toExternalForm());
        alert.getDialogPane().setStyle("-fx-background-color:#1E2130;");

        StringBuilder sb = new StringBuilder();
        sb.append("📁 Catégorie : ").append(task.getCategory()).append("\n");
        sb.append("⚡ Priorité  : ").append(task.getPriority()).append("\n");
        sb.append("📅 Échéance  : ").append(task.getDeadline() != null ? task.getDeadline() : "-").append("\n");
        sb.append("🔄 Statut    : ").append(task.getStatus()).append("\n");
        sb.append("⏱️ Heures    : ").append(task.getActualHours()).append(" / ").append(task.getEstimatedHours()).append(" h\n\n");

        if (!task.getSubtasks().isEmpty()) {
            sb.append("📌 Sous-tâches :\n");
            for (Subtask s : task.getSubtasks()) {
                sb.append(s.isCompleted() ? "  ✅ " : "  ⬜ ").append(s.getTitle()).append("\n");
            }
        } else {
            sb.append("(Aucune sous-tâche)");
        }

        alert.setContentText(sb.toString());
        alert.showAndWait();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Label label(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill:#B0B3C6;-fx-font-size:12px;-fx-font-weight:bold;");
        return l;
    }

    private TextField styledTextField(String prompt) {
        TextField tf = new TextField();
        tf.setPromptText(prompt);
        tf.setStyle("-fx-background-color:#2A2D3E;-fx-text-fill:#E0E0E0;-fx-background-radius:8;-fx-border-color:#3A3D50;-fx-border-radius:8;-fx-padding:8 12;");
        return tf;
    }

    private void styleAlert(Alert alert) {
        alert.getDialogPane().getStylesheets().add(getClass().getResource("/css/style.css").toExternalForm());
        alert.getDialogPane().setStyle("-fx-background-color:#1E2130;");
    }
}
