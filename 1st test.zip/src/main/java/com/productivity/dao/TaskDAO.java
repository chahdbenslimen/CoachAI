package com.productivity.dao;

import com.productivity.model.Subtask;
import com.productivity.model.Task;
import com.productivity.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class TaskDAO {

    // ──────────────────────────────────────────────
    //  TASKS
    // ──────────────────────────────────────────────

    public boolean createTask(Task task) {
        String sql = "INSERT INTO tasks (user_id, title, description, category, priority, status, deadline, estimated_hours) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, task.getUserId());
            ps.setString(2, task.getTitle());
            ps.setString(3, task.getDescription());
            ps.setString(4, task.getCategory().name());
            ps.setString(5, task.getPriority().name());
            ps.setString(6, task.getStatus().name());
            ps.setDate(7, task.getDeadline() != null ? Date.valueOf(task.getDeadline()) : null);
            ps.setDouble(8, task.getEstimatedHours());
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) task.setId(keys.getInt(1));
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateTask(Task task) {
        String sql = "UPDATE tasks SET title=?, description=?, category=?, priority=?, status=?, deadline=?, estimated_hours=?, actual_hours=?, completed_at=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, task.getTitle());
            ps.setString(2, task.getDescription());
            ps.setString(3, task.getCategory().name());
            ps.setString(4, task.getPriority().name());
            ps.setString(5, task.getStatus().name());
            ps.setDate(6, task.getDeadline() != null ? Date.valueOf(task.getDeadline()) : null);
            ps.setDouble(7, task.getEstimatedHours());
            ps.setDouble(8, task.getActualHours());
            ps.setTimestamp(9, task.getCompletedAt() != null ? Timestamp.valueOf(task.getCompletedAt()) : null);
            ps.setInt(10, task.getId());
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteTask(int taskId) {
        String sql = "DELETE FROM tasks WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, taskId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Task> getTasksByUser(int userId) {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM tasks WHERE user_id=? ORDER BY priority DESC, deadline ASC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) tasks.add(mapTask(rs));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    public List<Task> getTasksByStatus(int userId, Task.Status status) {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM tasks WHERE user_id=? AND status=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setString(2, status.name());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) tasks.add(mapTask(rs));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return tasks;
    }

    // ──────────────────────────────────────────────
    //  SUBTASKS
    // ──────────────────────────────────────────────

    public boolean createSubtask(Subtask subtask) {
        String sql = "INSERT INTO subtasks (task_id, title, is_completed, order_index) VALUES (?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, subtask.getTaskId());
            ps.setString(2, subtask.getTitle());
            ps.setBoolean(3, subtask.isCompleted());
            ps.setInt(4, subtask.getOrderIndex());
            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) subtask.setId(keys.getInt(1));
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateSubtaskStatus(int subtaskId, boolean completed) {
        String sql = "UPDATE subtasks SET is_completed=? WHERE id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setBoolean(1, completed);
            ps.setInt(2, subtaskId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Subtask> getSubtasksByTask(int taskId) {
        List<Subtask> subtasks = new ArrayList<>();
        String sql = "SELECT * FROM subtasks WHERE task_id=? ORDER BY order_index";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, taskId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Subtask s = new Subtask();
                s.setId(rs.getInt("id"));
                s.setTaskId(rs.getInt("task_id"));
                s.setTitle(rs.getString("title"));
                s.setCompleted(rs.getBoolean("is_completed"));
                s.setOrderIndex(rs.getInt("order_index"));
                subtasks.add(s);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return subtasks;
    }

    public boolean deleteSubtasksByTask(int taskId) {
        String sql = "DELETE FROM subtasks WHERE task_id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, taskId);
            return ps.executeUpdate() >= 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // ──────────────────────────────────────────────
    //  STATS
    // ──────────────────────────────────────────────

    public int countByStatus(int userId, Task.Status status) {
        String sql = "SELECT COUNT(*) FROM tasks WHERE user_id=? AND status=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ps.setString(2, status.name());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getInt(1);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public double totalActualHours(int userId) {
        String sql = "SELECT SUM(actual_hours) FROM tasks WHERE user_id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getDouble(1);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // ──────────────────────────────────────────────
    //  MAPPER
    // ──────────────────────────────────────────────

    private Task mapTask(ResultSet rs) throws SQLException {
        Task t = new Task();
        t.setId(rs.getInt("id"));
        t.setUserId(rs.getInt("user_id"));
        t.setTitle(rs.getString("title"));
        t.setDescription(rs.getString("description"));
        t.setCategory(Task.Category.valueOf(rs.getString("category")));
        t.setPriority(Task.Priority.valueOf(rs.getString("priority")));
        t.setStatus(Task.Status.valueOf(rs.getString("status")));
        Date d = rs.getDate("deadline");
        if (d != null) t.setDeadline(d.toLocalDate());
        t.setEstimatedHours(rs.getDouble("estimated_hours"));
        t.setActualHours(rs.getDouble("actual_hours"));
        Timestamp created = rs.getTimestamp("created_at");
        if (created != null) t.setCreatedAt(created.toLocalDateTime());
        Timestamp completed = rs.getTimestamp("completed_at");
        if (completed != null) t.setCompletedAt(completed.toLocalDateTime());
        return t;
    }
}
