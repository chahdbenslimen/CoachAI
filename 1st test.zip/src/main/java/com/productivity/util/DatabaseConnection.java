package com.productivity.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Singleton database connection manager.
 */
public class DatabaseConnection {

    private static final String URL      = "jdbc:mysql://localhost:3306/productivity_coach?useSSL=false&serverTimezone=UTC";
    private static final String USER     = "root";       // Change to your MySQL username
    private static final String PASSWORD = "";       // Change to your MySQL password

    private static Connection connection;

    private DatabaseConnection() {}

    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
