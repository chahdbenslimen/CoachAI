# 🧠 ProductivityCoach — Coach Intelligent de Productivité Assisté par IA

Application desktop JavaFX avec intégration de l'API Gemini.

---

## 📁 Structure du projet

```
ProductivityCoach/
├── pom.xml
├── sql/
│   ├── schema.sql          ← Script de création de la base de données
│   ├── use_case.puml       ← Diagramme de cas d'utilisation (PlantUML)
│   └── class_diagram.puml  ← Diagramme de classes (PlantUML)
└── src/main/
    ├── java/com/productivity/
    │   ├── Main.java                         ← Point d'entrée
    │   ├── model/        User, Task, Subtask
    │   ├── dao/          UserDAO, TaskDAO
    │   ├── service/      UserService, TaskService
    │   ├── ai/           GeminiService
    │   ├── controller/   Login, Register, Dashboard, Tasks, AIAssistant, Stats, Profile
    │   └── util/         DatabaseConnection, SessionManager
    └── resources/
        ├── fxml/         Login, Register, Dashboard, Tasks, AIAssistant, Stats, Profile
        └── css/          style.css
```

---

## ⚙️ Prérequis

- Java 17+
- Maven 3.8+
- MySQL 8+
- Clé API Gemini (https://aistudio.google.com)

---

## 🚀 Installation & Lancement

### 1. Créer la base de données

```bash
mysql -u root -p < sql/schema.sql
```

### 2. Configurer la connexion MySQL

Éditez `src/main/java/com/productivity/util/DatabaseConnection.java` :

```java
private static final String USER     = "votre_user";
private static final String PASSWORD = "votre_mot_de_passe";
```

### 3. Ajouter votre clé API Gemini

Éditez `src/main/java/com/productivity/ai/GeminiService.java` :

```java
private static final String API_KEY = "VOTRE_CLE_API_ICI";
```

### 4. Lancer l'application

```bash
mvn javafx:run
```

---

## 🎯 Fonctionnalités

| Fonctionnalité              | Description                                          |
|-----------------------------|------------------------------------------------------|
| 🔐 Authentification         | Inscription / Connexion avec hash BCrypt             |
| 📋 Gestion des tâches       | CRUD complet avec catégories, priorités, statuts     |
| 🤖 Assistant IA             | 4 fonctionnalités IA via Gemini API                  |
| 📊 Statistiques             | Taux de complétion, heures, historique               |
| 👤 Profil utilisateur       | Rythme de travail, objectifs hebdomadaires           |

### Fonctionnalités IA (Gemini)
1. **Reformulation** d'objectifs flous en objectifs SMART
2. **Suggestion de priorité** basée sur le contenu de la tâche
3. **Décomposition** d'une grosse tâche en sous-tâches
4. **Plan de travail** jour par jour avec deadline
5. **Conseil personnalisé** basé sur les statistiques utilisateur

---

## 🏗️ Architecture (couches)

```
UI (JavaFX FXML + Controllers)
        ↓
Service Layer (business logic)
        ↓
DAO Layer (accès données)
        ↓
MySQL Database
        ↓ (parallèle)
Gemini API (via HTTP/OkHttp)
```

---

## 📊 Diagrammes UML

Les fichiers `.puml` dans `/sql/` peuvent être visualisés sur https://www.plantuml.com/plantuml/uml/
ou avec le plugin PlantUML dans IntelliJ / VS Code.

---

## 🔑 Stack Technique

| Composant    | Technologie              |
|--------------|--------------------------|
| UI           | JavaFX 21 + FXML         |
| Build        | Maven                    |
| Base données | MySQL 8                  |
| ORM/accès DB | JDBC pur                 |
| IA           | Google Gemini 1.5 Flash  |
| HTTP         | OkHttp 4                 |
| JSON         | org.json                 |
| Sécurité     | jBCrypt (hash passwords) |
